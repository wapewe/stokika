// Secure Configuration Loader - Production Ready
// This file loads configuration from a secure PHP endpoint
// NEVER expose credentials in client-side code

class ConfigLoader {
    constructor() {
        this.config = null;
        this.isLoaded = false;
        this.loadPromise = null;
    }

    async loadConfig() {
        if (this.isLoaded) return this.config;
        if (this.loadPromise) return this.loadPromise;

        this.loadPromise = (async () => {
            try {
                const data = await this.fetchFromBackend();
                this.config = {
                    supabaseUrl: data.supabaseUrl,
                    supabaseAnonKey: data.supabaseAnonKey
                };
                
                // Set global variables for other scripts
                window.SUPABASE_URL = this.config.supabaseUrl;
                window.SUPABASE_ANON_KEY = this.config.supabaseAnonKey;
                
                this.isLoaded = true;
                
                // Dispatch event to notify config is loaded
                window.dispatchEvent(new Event('supabase-config-loaded'));
                
                return this.config;
            } catch (error) {
                console.error('Failed to load configuration:', error);
                throw new Error('Configuration error');
            }
        })();

        return this.loadPromise;
    }

    async fetchFromBackend() {
        // Check if running locally (file:// protocol or localhost)
        const isLocal = window.location.protocol === 'file:' || 
                       window.location.hostname === 'localhost' ||
                       window.location.hostname === '127.0.0.1';
        
        if (isLocal) {
            // For local development, use config.dev.php or environment-specific endpoint
            console.warn('⚠️ LOCAL DEVELOPMENT MODE: Using development configuration endpoint');
            console.warn('⚠️ Ensure you have a local .env file and config.dev.php configured');
            
            // Try to load from local dev endpoint
            try {
                const devResponse = await fetch('/api/config.dev.php', {
                    method: 'GET',
                    headers: { 
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    cache: 'no-cache'
                });
                
                if (devResponse.ok) {
                    const data = await devResponse.json();
                    if (data.supabaseUrl && data.supabaseAnonKey) {
                        return data;
                    }
                }
            } catch (error) {
                console.error('Failed to load from config.dev.php:', error);
            }
            
            // If dev endpoint fails, throw error - do NOT use hardcoded credentials
            throw new Error('Local development configuration not found. Please create /api/config.dev.php with proper environment variables.');
        }
        
        // Production: fetch from PHP endpoint
        console.log('Loading production config from secure PHP endpoint...');
        const apiUrl = '/api/config.php';
        
        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            cache: 'no-cache'
        });
        
        if (!response.ok) {
            throw new Error('Failed to load config from server (Status: ' + response.status + ')');
        }
        
        const data = await response.json();
        
        if (!data.supabaseUrl || !data.supabaseAnonKey) {
            throw new Error('Invalid config data received from server');
        }
        
        return data;
    }

    getConfig() {
        if (!this.isLoaded) {
            throw new Error('Configuration not loaded. Call loadConfig() first.');
        }
        return this.config;
    }
}

// Export singleton instance
window.ConfigLoader = new ConfigLoader();

// Auto-load config when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.ConfigLoader.loadConfig().catch(err => {
            console.error('Failed to auto-load config:', err);
        });
    });
} else {
    // DOM already loaded
    window.ConfigLoader.loadConfig().catch(err => {
        console.error('Failed to auto-load config:', err);
    });
}
