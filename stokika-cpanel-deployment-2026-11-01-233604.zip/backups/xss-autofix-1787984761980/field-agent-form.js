

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('fieldAgentForm');
    
    // Set max date for 18+ age restriction
    const dobInput = document.getElementById('dateOfBirth');
    const maxDate = new Date();
    maxDate.setFullYear(maxDate.getFullYear() - 18);
    dobInput.max = maxDate.toISOString().split('T')[0];

    dobInput.addEventListener('change', () => {
        const selected = new Date(dobInput.value);
        if (selected > maxDate) {
            dobInput.setCustomValidity('You must be at least 18 years old.');
            dobInput.reportValidity();
        } else {
            dobInput.setCustomValidity('');
        }
    });
    
    // Conditional field handlers
    setupConditionalFields();
    
    form.addEventListener('submit', handleFormSubmit);
});

function setupConditionalFields() {
    // Gender other field
    const genderSelect = document.getElementById('gender');
    const genderOtherField = document.getElementById('genderOtherField');
    
    genderSelect.addEventListener('change', () => {
        if (genderSelect.value === 'other') {
            genderOtherField.style.display = 'block';
            genderOtherField.querySelector('input').required = true;
        } else {
            genderOtherField.style.display = 'none';
            genderOtherField.querySelector('input').required = false;
            genderOtherField.querySelector('input').value = '';
        }
    });
    
    // Employment details
    const employmentRadios = document.querySelectorAll('input[name="currentlyEmployed"]');
    const employmentDetails = document.getElementById('employmentDetails');
    
    employmentRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'yes' && radio.checked) {
                employmentDetails.style.display = 'block';
                employmentDetails.querySelector('input').required = true;
            } else {
                employmentDetails.style.display = 'none';
                employmentDetails.querySelector('input').required = false;
                employmentDetails.querySelector('input').value = '';
            }
        });
    });
    
    // Field experience details
    const fieldExpRadios = document.querySelectorAll('input[name="hasFieldExperience"]');
    const fieldExpDetails = document.getElementById('fieldExperienceDetails');
    
    fieldExpRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'yes' && radio.checked) {
                fieldExpDetails.style.display = 'block';
            } else {
                fieldExpDetails.style.display = 'none';
                document.querySelectorAll('input[name="fieldExperienceTypes"]').forEach(cb => cb.checked = false);
                document.getElementById('otherExperienceField').style.display = 'none';
            }
        });
    });
    
    // Other experience field
    const otherExpCheckbox = document.getElementById('exp-other');
    const otherExpField = document.getElementById('otherExperienceField');
    
    if (otherExpCheckbox) {
        otherExpCheckbox.addEventListener('change', () => {
            if (otherExpCheckbox.checked) {
                otherExpField.style.display = 'block';
                otherExpField.querySelector('input').required = true;
            } else {
                otherExpField.style.display = 'none';
                otherExpField.querySelector('input').required = false;
                otherExpField.querySelector('input').value = '';
            }
        });
    }
    
    // Local languages field
    const localLangCheckbox = document.getElementById('lang-local');
    const localLangField = document.getElementById('localLanguagesField');
    
    if (localLangCheckbox) {
        localLangCheckbox.addEventListener('change', () => {
            if (localLangCheckbox.checked) {
                localLangField.style.display = 'block';
            } else {
                localLangField.style.display = 'none';
                localLangField.querySelector('input').value = '';
            }
        });
    }
    
    // Market knowledge details
    const marketRadios = document.querySelectorAll('input[name="familiarWithMarket"]');
    const marketDetails = document.getElementById('marketKnowledgeDetails');
    
    marketRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'yes' && radio.checked) {
                marketDetails.style.display = 'block';
                marketDetails.querySelector('input').required = true;
            } else {
                marketDetails.style.display = 'none';
                marketDetails.querySelector('input').required = false;
                marketDetails.querySelector('input').value = '';
            }
        });
    });
    
    // Smartphone details
    const smartphoneRadios = document.querySelectorAll('input[name="ownsSmartphone"]');
    const smartphoneDetails = document.getElementById('smartphoneDetails');
    
    smartphoneRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'yes' && radio.checked) {
                smartphoneDetails.style.display = 'block';
                smartphoneDetails.querySelectorAll('input').forEach(input => input.required = true);
            } else {
                smartphoneDetails.style.display = 'none';
                smartphoneDetails.querySelectorAll('input').forEach(input => {
                    input.required = false;
                    input.value = '';
                });
            }
        });
    });
    
    // Start date other
    const startDateRadios = document.querySelectorAll('input[name="startDate"]');
    const startDateOther = document.getElementById('startDateOther');
    
    startDateRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'other' && radio.checked) {
                startDateOther.style.display = 'block';
                startDateOther.querySelector('input').required = true;
            } else {
                startDateOther.style.display = 'none';
                startDateOther.querySelector('input').required = false;
                startDateOther.querySelector('input').value = '';
            }
        });
    });
    
    // Unavailability details
    const availabilityRadios = document.querySelectorAll('input[name="weekdayAvailability"]');
    const unavailabilityDetails = document.getElementById('unavailabilityDetails');
    
    availabilityRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'no' && radio.checked) {
                unavailabilityDetails.style.display = 'block';
                unavailabilityDetails.querySelectorAll('select, input').forEach(field => field.required = true);
            } else {
                unavailabilityDetails.style.display = 'none';
                unavailabilityDetails.querySelectorAll('select, input').forEach(field => {
                    field.required = false;
                    field.value = '';
                });
            }
        });
    });
    
    // Transport details
    const transportRadios = document.querySelectorAll('input[name="hasTransport"]');
    const transportDetails = document.getElementById('transportDetails');
    
    transportRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'yes' && radio.checked) {
                transportDetails.style.display = 'block';
                transportDetails.querySelector('input').required = true;
            } else {
                transportDetails.style.display = 'none';
                transportDetails.querySelector('input').required = false;
                transportDetails.querySelector('input').value = '';
            }
        });
    });
    
    // Misconduct details
    const misconductRadios = document.querySelectorAll('input[name="hasMisconduct"]');
    const misconductDetails = document.getElementById('misconductDetails');
    
    misconductRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'yes' && radio.checked) {
                misconductDetails.style.display = 'block';
                misconductDetails.querySelector('textarea').required = true;
            } else {
                misconductDetails.style.display = 'none';
                misconductDetails.querySelector('textarea').required = false;
                misconductDetails.querySelector('textarea').value = '';
            }
        });
    });
    
    // Training no reason
    const trainingRadios = document.querySelectorAll('input[name="agreesToTraining"]');
    const trainingNoReason = document.getElementById('trainingNoReason');
    
    trainingRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'no' && radio.checked) {
                trainingNoReason.style.display = 'block';
                trainingNoReason.querySelector('textarea').required = true;
            } else {
                trainingNoReason.style.display = 'none';
                trainingNoReason.querySelector('textarea').required = false;
                trainingNoReason.querySelector('textarea').value = '';
            }
        });
    });
}

async function handleFormSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    // Enforce 18+ age
    const dob = new Date(data.dateOfBirth);
    const minAge = new Date();
    minAge.setFullYear(minAge.getFullYear() - 18);
    if (dob > minAge) {
        alert('You must be at least 18 years old to apply.');
        return;
    }

    try {
        // Initialize Supabase
        const supabase = initSupabase();
        if (!supabase) {
            throw new Error('Failed to initialize Supabase');
        }
        
        // Generate unique application code via RPC
        const { data: codeData, error: codeError } = await supabase.rpc('generate_field_agent_code');
        if (codeError) throw codeError;
        const applicationCode = codeData;

        const { error } = await supabase
            .from('field_agents')
            .insert({
                application_code: applicationCode,
                full_name: data.fullName,
                phone: data.phone,
                email: data.email,
                id_number: data.idNumber,
                date_of_birth: data.dateOfBirth,
                gender: data.gender === 'other' ? data.genderOther : data.gender,
                county: data.county,
                sub_county: data.subCounty,
                town: data.town,
                ward: data.ward,
                kin_name: data.kinName,
                kin_relationship: data.kinRelationship,
                kin_phone: data.kinPhone,
                kin_address: data.kinAddress,
                currently_employed: data.currentlyEmployed,
                current_employer: data.currentEmployer,
                has_previous_experience: data.hasFieldExperience,
                experience: Array.isArray(data.fieldExperienceTypes) ? data.fieldExperienceTypes.join(', ') : data.fieldExperienceTypes || null,
                experience_other: data.otherExperience,
                years_experience: data.yearsExperience,
                sme_experience: data.experienceDescription,
                languages: Array.isArray(data.languages) ? data.languages.join(', ') : data.languages || null,
                local_languages: data.localLanguages,
                local_market_familiar: data.familiarWithMarket,
                market_areas: data.marketAreas,
                owns_smartphone: data.ownsSmartphone,
                phone_brand: data.phoneBrand,
                android_version: data.androidVersion,
                can_use_smartphone: data.canUseSmartphone,
                internet_access: Array.isArray(data.internetAccess) ? data.internetAccess.join(', ') : data.internetAccess || null,
                start_date: data.startDate,
                start_date_other: data.startDateSpecify,
                weekday_availability: data.weekdayAvailability,
                unavailable_day: data.unavailableDay,
                unavailability_reason: data.unavailabilityReason,
                working_hours: data.workingHours,
                has_transport: data.hasTransport,
                transport_type: data.transportType,
                referee1_name: data.ref1Name,
                referee1_phone: data.ref1Phone,
                referee1_relationship: data.ref1Relationship,
                referee2_name: data.ref2Name,
                referee2_phone: data.ref2Phone,
                referee2_relationship: data.ref2Relationship,
                criminal_history: data.hasMisconduct,
                criminal_explanation: data.misconductExplanation,
                code_of_conduct: data.agreesToConduct,
                training_willingness: data.agreesToTraining,
                kra_pin: data.kraPin,
                agreement: data.agreement ? 'agreed' : 'not_agreed',
                status: 'pending',
                application_date: new Date().toISOString(),
                timezone: 'Africa/Nairobi'
            });

        if (error) throw error;

        // Show success message with application code
        const successMsg = `Application submitted successfully!\n\nYour Application Code: ${applicationCode}\n\nIMPORTANT: Save this code! You will need it to complete your kit payment.\n\nWe will review your application and send you a payment link within 3-5 business days.`;
        alert(successMsg);
        e.target.reset();
    } catch (error) {
        console.error('Error submitting application:', error);
        alert('Error submitting application. Please try again.');
    }
}