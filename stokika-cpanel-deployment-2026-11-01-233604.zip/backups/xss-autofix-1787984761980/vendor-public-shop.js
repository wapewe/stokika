// Vendor Public Shop Frontend
class VendorPublicShop {
    constructor(shopSlug) {
        this.shopSlug = shopSlug;
        this.supabase = window.supabase;
        this.cart = JSON.parse(localStorage.getItem(`cart_${shopSlug}`) || '[]');
        this.shopProfile = null;
        this.theme = null;
    }

    async init() {
        try {
            await this.loadShopData();
            this.renderShop();
            this.setupEventListeners();
        } catch (error) {
            console.error('Error initializing shop:', error);
            this.renderError('Shop not found or unavailable');
        }
    }

    async loadShopData() {
        // Load shop profile
        const { data: profile, error: profileError } = await this.supabase
            .from('vendor_shop_profiles')
            .select('*')
            .eq('shop_slug', this.shopSlug)
            .eq('is_active', true)
            .single();

        if (profileError) throw profileError;
        this.shopProfile = profile;

        // Load theme
        const { data: theme } = await this.supabase
            .from('vendor_shop_themes')
            .select('*')
            .eq('vendor_id', profile.vendor_id)
            .single();

        this.theme = theme || {};
    }

    async loadProducts(filters = {}) {
        let query = this.supabase
            .from('vendor_inventory')
            .select('*')
            .eq('vendor_id', this.shopProfile.vendor_id)
            .eq('is_active', true)
            .order('created_at', { ascending: false });

        if (filters.category) query = query.eq('category', filters.category);
        if (filters.search) query = query.ilike('product_name', `%${filters.search}%`);

        const { data, error } = await query;
        if (error) throw error;
        return data || [];
    }

    renderShop() {
        const container = document.getElementById('shopContainer');
        if (!container) return;

        // Apply theme
        this.applyTheme();

        container.innerHTML = `
            <div class="shop-header">
                ${this.shopProfile.banner_url ? `<img src="${this.shopProfile.banner_url}" alt="Shop Banner" class="shop-banner">` : ''}
                <div class="shop-info">
                    ${this.shopProfile.logo_url ? `<img src="${this.shopProfile.logo_url}" alt="Logo" class="shop-logo">` : ''}
                    <h1>${this.shopProfile.shop_name}</h1>
                    ${this.shopProfile.tagline ? `<p class="tagline">${this.shopProfile.tagline}</p>` : ''}
                    <div class="shop-stats">
                        <span>⭐ ${this.shopProfile.avg_rating || 0}/5</span>
                        <span>📦 ${this.shopProfile.total_orders || 0} orders</span>
                    </div>
                </div>
            </div>

            <div class="shop-nav">
                <div class="nav-left">
                    <input type="text" id="searchInput" placeholder="Search products..." class="search-input">
                    <select id="categoryFilter" class="category-filter">
                        <option value="">All Categories</option>
                    </select>
                </div>
                <div class="nav-right">
                    <button id="cartBtn" class="cart-btn">
                        🛒 Cart (<span id="cartCount">${this.cart.length}</span>)
                    </button>
                </div>
            </div>

            <div id="productsGrid" class="products-grid">
                <div class="loading">Loading products...</div>
            </div>

            <div id="cartModal" class="modal-overlay" style="display: none;">
                <div class="modal-content">
                    <h2>Shopping Cart</h2>
                    <div id="cartItems"></div>
                    <div id="cartTotal"></div>
                    <div class="cart-actions">
                        <button id="checkoutBtn" class="btn-primary">Checkout</button>
                        <button onclick="this.closest('.modal-overlay').style.display='none'" class="btn-secondary">Continue Shopping</button>
                    </div>
                </div>
            </div>

            <div id="checkoutModal" class="modal-overlay" style="display: none;">
                <div class="modal-content">
                    <h2>Checkout</h2>
                    <form id="checkoutForm">
                        <div class="form-grid">
                            <div>
                                <label>Full Name *</label>
                                <input type="text" name="customer_name" required>
                            </div>
                            <div>
                                <label>Phone Number *</label>
                                <input type="tel" name="customer_phone" required>
                            </div>
                            <div>
                                <label>Email</label>
                                <input type="email" name="customer_email">
                            </div>
                            <div>
                                <label>County *</label>
                                <select name="delivery_county" required>
                                    <option value="">Select County</option>
                                    <option value="Nairobi">Nairobi</option>
                                    <option value="Mombasa">Mombasa</option>
                                    <option value="Kisumu">Kisumu</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label>Delivery Address *</label>
                            <textarea name="delivery_address" required rows="3"></textarea>
                        </div>
                        <div>
                            <label>Delivery Notes</label>
                            <textarea name="delivery_notes" rows="2"></textarea>
                        </div>
                        <div class="order-summary">
                            <div id="checkoutSummary"></div>
                        </div>
                        <div class="checkout-actions">
                            <button type="submit" class="btn-primary">Place Order</button>
                            <button type="button" onclick="this.closest('.modal-overlay').style.display='none'" class="btn-secondary">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        `;

        this.loadAndRenderProducts();
    }

    applyTheme() {
        const style = document.createElement('style');
        style.textContent = `
            :root {
                --primary-color: ${this.theme.primary_color || '#3b82f6'};
                --secondary-color: ${this.theme.secondary_color || '#10b981'};
                --accent-color: ${this.theme.accent_color || '#f59e0b'};
                --font-family: ${this.theme.font_family || 'Inter'}, sans-serif;
            }
            
            .shop-header {
                text-align: center;
                margin-bottom: 30px;
            }
            
            .shop-banner {
                width: 100%;
                height: 200px;
                object-fit: cover;
                border-radius: 8px;
                margin-bottom: 20px;
            }
            
            .shop-logo {
                width: 80px;
                height: 80px;
                border-radius: 50%;
                margin-bottom: 15px;
            }
            
            .shop-info h1 {
                color: var(--primary-color);
                font-family: var(--font-family);
                margin: 0 0 10px 0;
            }
            
            .tagline {
                color: #6b7280;
                font-style: italic;
                margin-bottom: 15px;
            }
            
            .shop-stats span {
                margin: 0 15px;
                color: #374151;
            }
            
            .shop-nav {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 30px;
                gap: 20px;
            }
            
            .nav-left {
                display: flex;
                gap: 15px;
                flex: 1;
            }
            
            .search-input, .category-filter {
                padding: 10px;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-family: var(--font-family);
            }
            
            .search-input {
                flex: 1;
                max-width: 300px;
            }
            
            .cart-btn {
                background: var(--primary-color);
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                cursor: pointer;
                font-family: var(--font-family);
            }
            
            .products-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
                gap: 20px;
                margin-bottom: 40px;
            }
            
            .product-card {
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                overflow: hidden;
                transition: transform 0.2s;
            }
            
            .product-card:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            }
            
            .product-image {
                width: 100%;
                height: 200px;
                object-fit: cover;
            }
            
            .product-info {
                padding: 15px;
            }
            
            .product-name {
                font-weight: 600;
                margin-bottom: 8px;
                color: #111827;
            }
            
            .product-price {
                font-size: 18px;
                font-weight: 700;
                color: var(--primary-color);
                margin-bottom: 10px;
            }
            
            .add-to-cart {
                width: 100%;
                background: var(--secondary-color);
                color: white;
                border: none;
                padding: 10px;
                border-radius: 6px;
                cursor: pointer;
                font-family: var(--font-family);
            }
            
            .modal-overlay {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 1000;
            }
            
            .modal-content {
                background: white;
                padding: 30px;
                border-radius: 8px;
                max-width: 600px;
                width: 90%;
                max-height: 90vh;
                overflow-y: auto;
            }
            
            .form-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 15px;
                margin-bottom: 15px;
            }
            
            .form-grid input, .form-grid select {
                padding: 10px;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                font-family: var(--font-family);
            }
            
            .btn-primary {
                background: var(--primary-color);
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 6px;
                cursor: pointer;
                font-family: var(--font-family);
            }
            
            .btn-secondary {
                background: #6b7280;
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 6px;
                cursor: pointer;
                font-family: var(--font-family);
            }
        `;
        document.head.appendChild(style);
    }

    async loadAndRenderProducts() {
        try {
            const products = await this.loadProducts();
            this.renderProducts(products);
            await this.loadCategories();
        } catch (error) {
            console.error('Error loading products:', error);
            document.getElementById('productsGrid').innerHTML = '<p>Error loading products</p>';
        }
    }

    renderProducts(products) {
        const grid = document.getElementById('productsGrid');
        
        if (products.length === 0) {
            grid.innerHTML = '<p>No products available</p>';
            return;
        }

        grid.innerHTML = products.map(product => `
            <div class="product-card">
                ${product.images && product.images[0] ? 
                    `<img src="${product.images[0]}" alt="${product.product_name}" class="product-image">` :
                    '<div class="product-image" style="background: #f3f4f6; display: flex; align-items: center; justify-content: center;">No Image</div>'
                }
                <div class="product-info">
                    <div class="product-name">${product.product_name}</div>
                    <div class="product-price">KES ${parseFloat(product.selling_price).toLocaleString()}</div>
                    ${product.description ? `<p style="font-size: 14px; color: #6b7280; margin-bottom: 10px;">${product.description.substring(0, 100)}...</p>` : ''}
                    <button class="add-to-cart" onclick="vendorShop.addToCart('${product.id}')">
                        Add to Cart
                    </button>
                </div>
            </div>
        `).join('');
    }

    async loadCategories() {
        const { data } = await this.supabase
            .from('vendor_inventory')
            .select('category')
            .eq('vendor_id', this.shopProfile.vendor_id)
            .eq('is_active', true);

        const categories = [...new Set(data?.map(item => item.category).filter(Boolean))];
        
        const select = document.getElementById('categoryFilter');
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            select.appendChild(option);
        });
    }

    setupEventListeners() {
        // Search
        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.filterProducts({ search: e.target.value });
        });

        // Category filter
        document.getElementById('categoryFilter').addEventListener('change', (e) => {
            this.filterProducts({ category: e.target.value });
        });

        // Cart button
        document.getElementById('cartBtn').addEventListener('click', () => {
            this.showCart();
        });

        // Checkout
        document.getElementById('checkoutBtn').addEventListener('click', () => {
            this.showCheckout();
        });

        // Checkout form
        document.getElementById('checkoutForm').addEventListener('submit', (e) => {
            this.processOrder(e);
        });
    }

    async filterProducts(filters) {
        const products = await this.loadProducts(filters);
        this.renderProducts(products);
    }

    async addToCart(productId) {
        try {
            const { data: product } = await this.supabase
                .from('vendor_inventory')
                .select('*')
                .eq('id', productId)
                .single();

            const existingItem = this.cart.find(item => item.id === productId);
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                this.cart.push({
                    id: productId,
                    name: product.product_name,
                    price: product.selling_price,
                    quantity: 1
                });
            }

            this.saveCart();
            this.updateCartCount();
            showUserMessage('Added to cart', 'success');
        } catch (error) {
            console.error('Error adding to cart:', error);
            showUserMessage('Failed to add to cart', 'error');
        }
    }

    showCart() {
        const modal = document.getElementById('cartModal');
        const itemsContainer = document.getElementById('cartItems');
        const totalContainer = document.getElementById('cartTotal');

        if (this.cart.length === 0) {
            itemsContainer.innerHTML = '<p>Your cart is empty</p>';
            totalContainer.innerHTML = '';
            modal.style.display = 'flex';
            return;
        }

        const total = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        itemsContainer.innerHTML = this.cart.map(item => `
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px; border-bottom: 1px solid #e5e7eb;">
                <div>
                    <div style="font-weight: 600;">${item.name}</div>
                    <div style="color: #6b7280;">KES ${parseFloat(item.price).toLocaleString()} x ${item.quantity}</div>
                </div>
                <div>
                    <button onclick="vendorShop.updateCartQuantity('${item.id}', ${item.quantity - 1})" style="background: #ef4444; color: white; border: none; padding: 5px 10px; border-radius: 4px; margin-right: 5px;">-</button>
                    <button onclick="vendorShop.updateCartQuantity('${item.id}', ${item.quantity + 1})" style="background: #10b981; color: white; border: none; padding: 5px 10px; border-radius: 4px;">+</button>
                </div>
            </div>
        `).join('');

        totalContainer.innerHTML = `<div style="font-size: 18px; font-weight: 700; text-align: right; margin-top: 15px;">Total: KES ${total.toLocaleString()}</div>`;
        modal.style.display = 'flex';
    }

    updateCartQuantity(productId, newQuantity) {
        if (newQuantity <= 0) {
            this.cart = this.cart.filter(item => item.id !== productId);
        } else {
            const item = this.cart.find(item => item.id === productId);
            if (item) item.quantity = newQuantity;
        }
        
        this.saveCart();
        this.updateCartCount();
        this.showCart();
    }

    showCheckout() {
        document.getElementById('cartModal').style.display = 'none';
        
        const total = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const summary = document.getElementById('checkoutSummary');
        
        summary.innerHTML = `
            <h3>Order Summary</h3>
            ${this.cart.map(item => `
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span>${item.name} x ${item.quantity}</span>
                    <span>KES ${(item.price * item.quantity).toLocaleString()}</span>
                </div>
            `).join('')}
            <div style="border-top: 1px solid #e5e7eb; padding-top: 10px; margin-top: 10px; font-weight: 700;">
                <div style="display: flex; justify-content: space-between;">
                    <span>Total:</span>
                    <span>KES ${total.toLocaleString()}</span>
                </div>
            </div>
        `;
        
        document.getElementById('checkoutModal').style.display = 'flex';
    }

    async processOrder(event) {
        event.preventDefault();
        
        try {
            const formData = new FormData(event.target);
            const total = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            
            // Generate order number
            const orderNumber = 'ORD-' + Date.now();
            
            // Create order
            const { data: order, error: orderError } = await this.supabase
                .from('customer_orders')
                .insert([{
                    order_number: orderNumber,
                    vendor_id: this.shopProfile.vendor_id,
                    customer_name: formData.get('customer_name'),
                    customer_email: formData.get('customer_email'),
                    customer_phone: formData.get('customer_phone'),
                    delivery_address: formData.get('delivery_address'),
                    delivery_county: formData.get('delivery_county'),
                    delivery_notes: formData.get('delivery_notes'),
                    subtotal: total,
                    total_amount: total,
                    order_status: 'pending',
                    payment_status: 'pending'
                }])
                .select()
                .single();

            if (orderError) throw orderError;

            // Create order items
            const orderItems = this.cart.map(item => ({
                order_id: order.id,
                product_id: item.id,
                product_name: item.name,
                quantity: item.quantity,
                unit_price: item.price,
                total_price: item.price * item.quantity
            }));

            const { error: itemsError } = await this.supabase
                .from('customer_order_items')
                .insert(orderItems);

            if (itemsError) throw itemsError;

            // Clear cart
            this.cart = [];
            this.saveCart();
            this.updateCartCount();

            // Show success
            document.getElementById('checkoutModal').style.display = 'none';
            showUserMessage(`Order ${orderNumber} placed successfully! The vendor will contact you soon.`, 'success');

        } catch (error) {
            console.error('Error processing order:', error);
            showUserMessage('Failed to place order. Please try again.', 'error');
        }
    }

    saveCart() {
        localStorage.setItem(`cart_${this.shopSlug}`, JSON.stringify(this.cart));
    }

    updateCartCount() {
        const countElement = document.getElementById('cartCount');
        if (countElement) {
            countElement.textContent = this.cart.length;
        }
    }

    renderError(message) {
        const container = document.getElementById('shopContainer');
        if (container) {
            container.innerHTML = `
                <div style="text-align: center; padding: 50px;">
                    <h2>Shop Not Available</h2>
                    <p>${message}</p>
                    <a href="/" class="btn-primary">Back to Home</a>
                </div>
            `;
        }
    }
}

// Initialize shop from URL
function initVendorShop() {
    const urlParams = new URLSearchParams(window.location.search);
    const shopSlug = urlParams.get('shop') || window.location.pathname.split('/').pop();
    
    if (shopSlug) {
        window.vendorShop = new VendorPublicShop(shopSlug);
        window.vendorShop.init();
    }
}

// Auto-initialize if on shop page
if (typeof window !== 'undefined' && document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initVendorShop);
} else if (typeof window !== 'undefined') {
    initVendorShop();
}