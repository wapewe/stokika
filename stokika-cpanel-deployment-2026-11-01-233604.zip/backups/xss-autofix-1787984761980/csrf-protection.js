// CSRF Protection Module - SECURE VERSION
// Uses server-side validation with httpOnly cookies
// Integrates with api/session-manager.php

class CSRFProtection {
    constructor() {
        this.tokenKey = 'csrf_token';
        this.headerName = 'X-CSRF-Token';
        this.token = null;
        this.isInitialized = false;
    }

    /**
     * Initialize CSRF protection - fetch token from server
     * This ensures the token is validated server-side
     */
    async init() {
        if (this.isInitialized && this.token) {
            return this.token;
        }

        try {
            // Try to get token from SecureSession first (preferred)
            if (window.SecureSession && window.SecureSession.isAuthenticated()) {
                this.token = window.SecureSession.getCsrfToken();
                this.isInitialized = true;
                return this.token;
            }

            // Fallback: fetch from session API
            const response = await fetch('/api/session.php?action=csrf-token', {
                method: 'GET',
                credentials: 'include', // Important: include session cookie
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const data = await response.json();
                this.token = data.csrfToken;
                this.isInitialized = true;
                return this.token;
            } else {
                console.warn('⚠️ CSRF token fetch failed. User may not be authenticated.');
                return null;
            }
        } catch (error) {
            console.error('CSRF initialization error:', error);
            return null;
        }
    }

    /**
     * Generate a new token (client-side fallback only for non-authenticated requests)
     * ⚠️ This should NOT be used for authenticated requests
     */
    generateClientToken() {
        console.warn('⚠️ Using client-side CSRF token. This is not secure for authenticated requests.');
        const token = Array.from(crypto.getRandomValues(new Uint8Array(32)))
            .map(b => b.toString(16).padStart(2, '0')).join('');
        
        // Store in sessionStorage only as fallback
        sessionStorage.setItem(this.tokenKey, token);
        return token;
    }

    /**
     * Get current CSRF token
     */
    async getToken() {
        // Try to use server-side token first
        if (!this.token || !this.isInitialized) {
            await this.init();
        }

        if (this.token) {
            return this.token;
        }

        // Fallback for non-authenticated requests
        let token = sessionStorage.getItem(this.tokenKey);
        if (!token) {
            token = this.generateClientToken();
        }
        return token;
    }

    /**
     * Validate token server-side
     * Returns true if valid, false otherwise
     */
    async validateToken(token) {
        if (!token) {
            return false;
        }

        try {
            // Use SecureSession if available (preferred)
            if (window.SecureSession && window.SecureSession.isAuthenticated()) {
                return await window.SecureSession.verifyCsrfToken(token);
            }

            // Fallback: direct API call
            const response = await fetch('/api/session.php?action=verify-csrf', {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ csrfToken: token })
            });

            if (response.ok) {
                const data = await response.json();
                
                // Update with new rotated token
                if (data.newToken) {
                    this.token = data.newToken;
                }
                
                return data.valid;
            }

            return false;
        } catch (error) {
            console.error('CSRF validation error:', error);
            return false;
        }
    }

    /**
     * Add CSRF token to form as hidden input
     */
    async addToForm(form) {
        if (!form) return;

        const token = await this.getToken();
        if (!token) {
            console.error('⚠️ No CSRF token available for form');
            return;
        }

        let input = form.querySelector('input[name="csrf_token"]');
        if (!input) {
            input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'csrf_token';
            form.appendChild(input);
        }
        input.value = token;
    }

    /**
     * Add CSRF token to request headers
     */
    async addToHeaders(headers = {}) {
        const token = await this.getToken();
        if (token) {
            headers[this.headerName] = token;
        } else {
            console.warn('⚠️ No CSRF token available for headers');
        }
        return headers;
    }

    /**
     * Protect a form with CSRF validation
     */
    async protectForm(form) {
        if (!form) return;

        await this.addToForm(form);

        // Add submit handler for validation
        form.addEventListener('submit', async (e) => {
            const formData = new FormData(form);
            const token = formData.get('csrf_token');

            if (!token) {
                e.preventDefault();
                alert('Security error: CSRF token missing');
                return false;
            }

            // Optional: Pre-validate before submission
            // Uncomment if you want client-side validation
            // const isValid = await this.validateToken(token);
            // if (!isValid) {
            //     e.preventDefault();
            //     alert('Security error: Invalid CSRF token. Please refresh and try again.');
            //     return false;
            // }
        });
    }

    /**
     * Secure fetch wrapper with automatic CSRF token
     */
    async secureFetch(url, options = {}) {
        // Initialize token if needed
        await this.init();

        // Add CSRF token to headers for non-GET requests
        if (!options.method || options.method.toUpperCase() !== 'GET') {
            options.headers = options.headers || {};
            await this.addToHeaders(options.headers);
        }

        // Always include credentials for session cookies
        options.credentials = options.credentials || 'include';

        return fetch(url, options);
    }

    /**
     * Rotate CSRF token after sensitive operations
     */
    async rotateToken() {
        try {
            if (window.SecureSession && window.SecureSession.isAuthenticated()) {
                // Token rotation is handled by SecureSession
                const newToken = window.SecureSession.getCsrfToken();
                this.token = newToken;
                return newToken;
            }

            // Fallback: request new token from server
            await this.init();
            return this.token;
        } catch (error) {
            console.error('Token rotation error:', error);
            return null;
        }
    }
}

// Export singleton instance
window.CSRFProtection = new CSRFProtection();

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', async () => {
    // Initialize CSRF protection
    await window.CSRFProtection.init();

    // Auto-protect all forms
    document.querySelectorAll('form').forEach(async (form) => {
        await window.CSRFProtection.protectForm(form);
    });

    // Monitor for dynamically added forms
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                if (node.nodeType === 1) { // Element node
                    if (node.tagName === 'FORM') {
                        window.CSRFProtection.protectForm(node);
                    }
                    // Check children
                    const forms = node.querySelectorAll('form');
                    forms.forEach(form => window.CSRFProtection.protectForm(form));
                }
            });
        });
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
});

// Convenience alias for secure fetch
window.secureFetch = (url, options) => window.CSRFProtection.secureFetch(url, options);
