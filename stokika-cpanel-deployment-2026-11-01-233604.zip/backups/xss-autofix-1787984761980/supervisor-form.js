

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('supervisorForm');

    // Set max date for 18+ age restriction
    const dobInput = document.getElementById('dateOfBirth');
    const maxDate = new Date();
    maxDate.setFullYear(maxDate.getFullYear() - 18);
    dobInput.max = maxDate.toISOString().split('T')[0];

    dobInput.addEventListener('change', () => {
        const selected = new Date(dobInput.value);
        if (selected > maxDate) {
            dobInput.setCustomValidity('You must be at least 18 years old.');
            dobInput.reportValidity();
        } else {
            dobInput.setCustomValidity('');
        }
    });

    form.addEventListener('submit', handleFormSubmit);
});

async function handleFormSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    // Enforce 18+ age
    const dob = new Date(data.dateOfBirth);
    const minAge = new Date();
    minAge.setFullYear(minAge.getFullYear() - 18);
    if (dob > minAge) {
        alert('You must be at least 18 years old to apply.');
        return;
    }

    try {
        // Initialize Supabase
        const supabase = initSupabase();
        if (!supabase) {
            throw new Error('Failed to initialize Supabase');
        }
        
        // Generate unique application code
        const { data: codeData, error: codeError } = await supabase.rpc('generate_supervisor_code');
        if (codeError) throw codeError;
        const applicationCode = codeData;

        const { error } = await supabase
            .from('supervisors')
            .insert({
                application_code: applicationCode,
                full_name: data.fullName,
                phone: data.phone,
                email: data.email,
                id_number: data.idNumber,
                date_of_birth: data.dateOfBirth,
                county: data.county,
                education_level: data.education,
                institution: data.institution,
                course: data.course,
                experience_areas: Array.isArray(data.experience) ? data.experience : [data.experience],
                years_experience: data.yearsExperience,
                experience_summary: data.experienceSummary,
                tech_skills: Array.isArray(data.techSkills) ? data.techSkills : [data.techSkills],
                tech_confidence: data.techConfidence,
                start_date: data.startDate,
                kra_pin: data.kraPin,
                status: 'pending'
            });

        if (error) throw error;

        // Show success message with application code
        const successMsg = `Application submitted successfully!\n\nYour Application Code: ${applicationCode}\n\nIMPORTANT: Save this code! You will need it to complete your kit payment.\n\nWe will review your application and send you a payment link within 48 hours.`;
        alert(successMsg);
        e.target.reset();
    } catch (error) {
        console.error('Error submitting application:', error);
        alert('Error submitting application. Please try again.');
    }
}