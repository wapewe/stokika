// Header scroll effect
const header = document.querySelector('.header');
const headerNav = document.querySelector('.header-nav');
const headerContent = document.querySelector('.header-content');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 100) {
        header?.classList.add('scrolled');
    } else {
        header?.classList.remove('scrolled');
    }
});

// Mobile menu toggle
headerContent?.addEventListener('click', (e) => {
    if (window.innerWidth <= 768 && e.target === headerContent) {
        headerNav?.classList.toggle('active');
    }
});

// Close mobile menu on link click
document.querySelectorAll('.header-nav a').forEach(link => {
    link.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
            headerNav?.classList.remove('active');
        }
    });
});

// Get Started Modal
const getStartedBtn = document.getElementById('getStartedBtn');
const getStartedModal = document.getElementById('getStartedModal');
const modalClose = document.getElementById('modalClose');
const joinVendor = document.getElementById('joinVendor');
const joinSupplier = document.getElementById('joinSupplier');

getStartedBtn?.addEventListener('click', () => {
    getStartedModal?.classList.add('active');
});

modalClose?.addEventListener('click', () => {
    getStartedModal?.classList.remove('active');
});

getStartedModal?.addEventListener('click', (e) => {
    if (e.target === getStartedModal) {
        getStartedModal.classList.remove('active');
    }
});

// Handle contact guidance link
document.getElementById('contactGuidance')?.addEventListener('click', (e) => {
    e.preventDefault();
    getStartedModal?.classList.remove('active');
    document.querySelector('#contact')?.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
});

// Mobile/tablet touch/click functionality for modal cards
function handleMobileCardClick(e) {
    if (window.innerWidth <= 1024) {
        const card = e.currentTarget;
        const registerBtn = card.querySelector('.register-btn');
        
        // If clicking the register button, don't toggle expansion
        if (e.target === registerBtn) {
            return;
        }
        
        e.preventDefault();
        card.classList.toggle('expanded');
    }
}

// Add click listeners to modal cards for mobile
document.addEventListener('DOMContentLoaded', () => {
    const vendorCard = document.getElementById('joinVendor');
    const supplierCard = document.getElementById('joinSupplier');
    
    vendorCard?.addEventListener('click', handleMobileCardClick);
    supplierCard?.addEventListener('click', handleMobileCardClick);
});

// Handle vendor card click (entire card)
joinVendor?.addEventListener('click', (e) => {
    if (e.target.classList.contains('register-btn')) {
        e.stopPropagation();
        getStartedModal?.classList.remove('active');
        const vendorModal = document.getElementById('vendorRegistrationModal');
        vendorModal?.classList.add('active');
        setTimeout(() => {
            showStep(1);
        }, 50);
    }
});

// Handle vendor register button click
document.querySelector('.register-btn.green')?.addEventListener('click', (e) => {
    e.stopPropagation();
    getStartedModal?.classList.remove('active');
    const vendorModal = document.getElementById('vendorRegistrationModal');
    vendorModal?.classList.add('active');
    setTimeout(() => {
        showStep(1);
    }, 50);
});

// Handle supplier card click (entire card)
joinSupplier?.addEventListener('click', (e) => {
    if (e.target.classList.contains('register-btn')) {
        e.stopPropagation();
        getStartedModal?.classList.remove('active');
        const supplierModal = document.getElementById('supplierRegistrationModal');
        supplierModal?.classList.add('active');
    }
});

// Handle supplier register button click
document.querySelector('.register-btn.blue')?.addEventListener('click', (e) => {
    e.stopPropagation();
    getStartedModal?.classList.remove('active');
    const supplierModal = document.getElementById('supplierRegistrationModal');
    supplierModal?.classList.add('active');
});

// Supplier Modal Close
const supplierModalClose = document.getElementById('supplierModalClose');
const supplierRegistrationModal = document.getElementById('supplierRegistrationModal');

supplierModalClose?.addEventListener('click', () => {
    supplierRegistrationModal?.classList.remove('active');
});

supplierRegistrationModal?.addEventListener('click', (e) => {
    if (e.target === supplierRegistrationModal) {
        supplierRegistrationModal.classList.remove('active');
    }
});

// County selection handler
document.addEventListener('change', (e) => {
    if (e.target.name === 'counties') {
        updateTownInputs();
    }
    
    if (e.target.id === 'otherCategory') {
        const otherField = document.getElementById('otherCategoryField');
        const otherInput = document.querySelector('input[name="otherCategoryText"]');
        if (e.target.checked) {
            otherField.style.display = 'block';
            otherInput.required = true;
        } else {
            otherField.style.display = 'none';
            otherInput.required = false;
        }
    }
    
    if (e.target.name === 'acceptsCredit') {
        const creditField = document.getElementById('creditDurationField');
        const creditSelect = document.getElementById('creditDurationSelect');
        if (e.target.value === 'yes') {
            creditField.style.display = 'block';
            creditSelect.required = true;
        } else {
            creditField.style.display = 'none';
            creditSelect.required = false;
        }
    }
});

function updateTownInputs() {
    const selectedCounties = Array.from(document.querySelectorAll('input[name="counties"]:checked')).map(cb => cb.value);
    const townsSection = document.getElementById('townsSection');
    const townInputs = document.getElementById('townInputs');
    
    if (selectedCounties.length > 0) {
        townsSection.style.display = 'block';
        townInputs.innerHTML = selectedCounties.map(county => `
            <div class="town-input-group">
                <label>${county} County</label>
                <input type="text" name="towns_${county.replace(/[^a-zA-Z0-9]/g, '_')}" placeholder="Enter towns/areas separated by commas (e.g., Nakuru Town, Naivasha, Gilgil)" required>
            </div>
        `).join('');
    } else {
        townsSection.style.display = 'none';
        townInputs.innerHTML = '';
    }
}

// Supplier form submission
document.getElementById('supplierRegistrationForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const counties = Array.from(document.querySelectorAll('input[name="counties"]:checked')).map(cb => cb.value);
    const categories = Array.from(document.querySelectorAll('input[name="categories"]:checked')).map(cb => cb.value);
    const paymentTerms = Array.from(document.querySelectorAll('input[name="paymentTerms"]:checked')).map(cb => cb.value);
    
    if (counties.length === 0) {
        alert('Please select at least one county.');
        return;
    }
    
    if (categories.length === 0) {
        alert('Please select at least one product category.');
        return;
    }
    
    if (paymentTerms.length === 0) {
        alert('Please select at least one payment term.');
        return;
    }
    
    const data = {
        company_name: formData.get('companyName'),
        contact_person: formData.get('contactPerson'),
        phone: formData.get('phone'),
        email: formData.get('email'),
        registration_number: formData.get('registrationNumber'),
        years_in_business: formData.get('yearsInBusiness'),
        number_of_employees: formData.get('numberOfEmployees'),
        counties: counties.join(', '),
        categories: categories.join(', '),
        other_category_text: formData.get('otherCategoryText'),
        minimum_order_quantity: formData.get('minimumOrderQuantity'),
        certifications: formData.get('certifications'),
        payment_terms: paymentTerms.join(', '),
        accepts_credit: formData.get('acceptsCredit'),
        credit_duration: formData.get('creditDuration'),
        created_at: new Date().toISOString()
    };
    
    try {
        const { data: result, error } = await supabase
            .from('suppliers')
            .insert([data]);
        
        if (error) throw error;
        
        alert('Supplier registration submitted successfully! We will contact you within 24 hours.');
        supplierRegistrationModal.classList.remove('active');
        e.target.reset();
        updateTownInputs();
    } catch (error) {
        console.error('Error submitting supplier registration:', error);
        alert('There was an error submitting your registration. Please try again.');
    }
});

// Hero Scroll Snap Navigation
const heroSection = document.querySelector('.hero-section');
const heroContainer = document.querySelector('.hero-container');
const slides = document.querySelectorAll('.hero-slide');
let currentSlide = 0;

// Animate hero elements when slide becomes active
function animateSlide(slideIndex) {
    slides.forEach((slide, index) => {
        if (index === slideIndex) {
            slide.classList.remove('loaded');
            setTimeout(() => {
                slide.classList.add('loaded');
            }, 100);
        }
    });
}

// Initial animation for first slide
setTimeout(() => {
    animateSlide(0);
}, 500);

// Smooth scroll to specific slide
function scrollToSlide(index) {
    if (heroContainer && slides[index]) {
        const slideHeight = window.innerHeight;
        heroContainer.scrollTo({
            top: index * slideHeight,
            behavior: 'smooth'
        });
        currentSlide = index;
    }
}

// Keyboard navigation
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' && currentSlide < slides.length - 1) {
        e.preventDefault();
        scrollToSlide(currentSlide + 1);
    } else if (e.key === 'ArrowUp' && currentSlide > 0) {
        e.preventDefault();
        scrollToSlide(currentSlide - 1);
    }
});

// Update current slide based on scroll position
heroContainer?.addEventListener('scroll', () => {
    const slideHeight = window.innerHeight;
    const scrollTop = heroContainer.scrollTop;
    const newSlide = Math.round(scrollTop / slideHeight);
    
    if (newSlide !== currentSlide && newSlide >= 0 && newSlide < slides.length) {
        currentSlide = newSlide;
        animateSlide(newSlide);
        
        // Update slide indicators
        document.querySelectorAll('.slide-dot').forEach((dot, index) => {
            if (index === newSlide) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });
    }
});

// Prevent page scroll until last slide
let isInHero = true;
window.addEventListener('wheel', (e) => {
    if (window.pageYOffset === 0 && currentSlide < slides.length - 1) {
        e.preventDefault();
        if (e.deltaY > 0) {
            scrollToSlide(currentSlide + 1);
        } else if (e.deltaY < 0 && currentSlide > 0) {
            scrollToSlide(currentSlide - 1);
        }
    } else if (window.pageYOffset === 0 && currentSlide === slides.length - 1 && e.deltaY > 0) {
        isInHero = false;
    }
}, { passive: false });

// Smooth scroll for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });

        }
    });
});

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe all cards and sections
document.querySelectorAll('.step-card, .audience-card, .testimonial-card, .pricing-card, .about-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'all 0.6s ease-out';
    observer.observe(el);
});

// Contact Form Submission
const contactForm = document.getElementById('contactForm');
contactForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(contactForm);
    const data = {
        name: formData.get('name'),
        phone: formData.get('phone'),
        email: formData.get('email'),
        business_type: formData.get('business_type'),
        other_business_type: formData.get('other_business_type'),
        message: formData.get('message'),
        created_at: new Date().toISOString()
    };
    
    // Show loading state
    const submitBtn = contactForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Sending...';
    submitBtn.disabled = true;
    
    try {
        // Initialize Supabase client
        const client = initSupabase();
        if (!client) {
            throw new Error('Supabase not initialized. Please check your configuration.');
        }
        
        const { data: result, error } = await client
            .from('contacts')
            .insert([data]);
        
        if (error) {
            console.error('Supabase error:', error);
            throw error;
        }
        
        alert('Thank you! We will contact you soon.');
        contactForm.reset();
    } catch (error) {
        console.error('Contact form error:', error);
        alert('Something went wrong. Please try again.');
    } finally {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
});

// Newsletter Form Submission
const newsletterForm = document.getElementById('newsletterForm');
newsletterForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(newsletterForm);
    const email = formData.get('email');
    
    if (!email || !email.includes('@')) {
        alert('Please enter a valid email address.');
        return;
    }
    
    const submitBtn = newsletterForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Subscribing...';
    submitBtn.disabled = true;
    
    try {
        // Initialize Supabase client
        const client = initSupabase();
        if (!client) {
            throw new Error('Supabase not initialized. Please check your configuration.');
        }
        
        const { data: result, error } = await client
            .from('newsletter_subscribers')
            .insert([{
                email: email,
                created_at: new Date().toISOString()
            }]);
        
        if (error) {
            if (error.code === '23505') { // Unique constraint violation
                alert('This email is already subscribed to our newsletter.');
            } else {
                throw error;
            }
        } else {
            alert('Successfully subscribed to newsletter!');
            newsletterForm.reset();
        }
    } catch (error) {
        alert('Something went wrong. Please try again.');
        console.error('Error:', error);
    } finally {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
});

// Back to Top Button
const backToTopBtn = document.getElementById('backToTop');
const scrollIndicator = document.querySelector('.scroll-indicator');

backToTopBtn?.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Back to top button visibility
let lastScroll = 0;

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    // Back to top button visibility (show after scrolling halfway)
    const halfwayPoint = (document.documentElement.scrollHeight - window.innerHeight) / 2;
    if (currentScroll > halfwayPoint) {
        backToTopBtn?.classList.add('visible');
    } else {
        backToTopBtn?.classList.remove('visible');
    }
    
    // Scroll indicator visibility (only show in hero section)
    if (currentScroll < window.innerHeight - 100) {
        scrollIndicator?.style.setProperty('opacity', '1');
        scrollIndicator?.style.setProperty('visibility', 'visible');
    } else {
        scrollIndicator?.style.setProperty('opacity', '0');
        scrollIndicator?.style.setProperty('visibility', 'hidden');
    }
    
    lastScroll = currentScroll;
});

// Success Stories Slider
let currentTestimonial = 0;
const testimonialSlider = document.querySelector('.testimonials-grid');
const testimonialDots = document.querySelectorAll('.testimonial-dot');
const totalTestimonials = 5;

function showTestimonial(index) {
    if (testimonialSlider) {
        testimonialSlider.style.transform = `translateX(-${index * 20}%)`;
        currentTestimonial = index;
        
        testimonialDots.forEach((dot, i) => {
            if (i === index) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });
    }
}

function nextTestimonial() {
    const next = (currentTestimonial + 1) % totalTestimonials;
    showTestimonial(next);
}

testimonialDots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
        showTestimonial(index);
        clearInterval(testimonialAutoSlide);
        testimonialAutoSlide = setInterval(nextTestimonial, 6000);
    });
});

let testimonialAutoSlide = setInterval(nextTestimonial, 6000);

document.addEventListener('DOMContentLoaded', () => {
    // Initialize success stories slider
    showTestimonial(0);
    
    // Initialize hero section interactions
    // Hero section mouse tracking for scroll indicator and slide indicators
    const scrollInd = document.getElementById('scrollIndicator');
    const slideIndicators = document.getElementById('slideIndicators');
    const slideDots = document.querySelectorAll('.slide-dot');
    
    heroSection?.addEventListener('mouseenter', () => {
        scrollInd?.classList.add('visible');
        slideIndicators?.classList.add('visible');
    });
    
    heroSection?.addEventListener('mouseleave', () => {
        scrollInd?.classList.remove('visible');
        slideIndicators?.classList.remove('visible');
    });
    
    heroSection?.addEventListener('mousemove', (e) => {
        if (scrollInd) {
            scrollInd.style.left = e.clientX + 'px';
            scrollInd.style.top = e.clientY + 'px';
            scrollInd.style.transform = 'rotate(180deg) translate(50%, 50%)';
        }
    });
    
    // Slide indicator click handlers
    slideDots.forEach(dot => {
        dot.addEventListener('click', () => {
            const slideIndex = parseInt(dot.getAttribute('data-slide'));
            scrollToSlide(slideIndex);
        });
    });
    
    // Auto-advance slides every 8 seconds
    let autoSlideInterval = setInterval(() => {
        if (currentSlide < slides.length - 1) {
            scrollToSlide(currentSlide + 1);
        } else {
            scrollToSlide(0);
        }
    }, 8000);
    
    // Stop auto-advance on user interaction
    heroContainer?.addEventListener('scroll', () => {
        clearInterval(autoSlideInterval);
    });
    
    heroContainer?.addEventListener('touchstart', () => {
        clearInterval(autoSlideInterval);
    });
});

// Vendor Registration Modal
const vendorRegistrationModal = document.getElementById('vendorRegistrationModal');
const vendorModalClose = document.getElementById('vendorModalClose');
const vendorRegistrationForm = document.getElementById('vendorRegistrationForm');
let currentStep = 1;
const totalSteps = 4;

// Close vendor modal
vendorModalClose?.addEventListener('click', () => {
    vendorRegistrationModal?.classList.remove('active');
    resetVendorForm();
});

vendorRegistrationModal?.addEventListener('click', (e) => {
    if (e.target === vendorRegistrationModal) {
        vendorRegistrationModal.classList.remove('active');
        resetVendorForm();
    }
});

// Step navigation
function showStep(step) {
    // Hide all steps
    document.querySelectorAll('.form-step').forEach(stepEl => {
        stepEl.classList.remove('active');
        stepEl.style.display = 'none';
    });
    
    // Show current step
    const currentStepEl = document.querySelector(`.form-step[data-step="${step}"]`);
    if (currentStepEl) {
        currentStepEl.classList.add('active');
        currentStepEl.style.display = 'block';
    }
    
    // Update progress indicators
    document.querySelectorAll('.progress-step').forEach((progressStep, index) => {
        if (index + 1 === step) {
            progressStep.classList.add('active');
        } else {
            progressStep.classList.remove('active');
        }
    });
    
    currentStep = step;
}

// Next button handlers
document.querySelectorAll('.btn-next').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Check if aspiring entrepreneur and redirect to BMC
        if (btn.id === 'stockToCanvas') {
            if (validateCurrentStep()) {
                submitVendorRegistration();
            }
            return;
        }
        
        // BMC navigation
        if (btn.id === 'bmcNext') {
            const textarea = document.querySelector('#bmcContent textarea');
            if (textarea && textarea.value.trim().length >= 30) {
                // Save current section data
                bmcData[currentBmcSection] = textarea.value.trim();
                completedSections.add(currentBmcSection);
                
                const sections = Object.keys(bmcSections);
                const currentIndex = sections.indexOf(currentBmcSection);
                
                if (currentIndex < sections.length - 1) {
                    currentBmcSection = sections[currentIndex + 1];
                    loadBmcSection(currentBmcSection);
                    updateBmcProgress();
                } else {
                    // All sections completed
                    document.getElementById('bmcNext').style.display = 'none';
                    document.getElementById('bmcComplete').style.display = 'block';
                    updateBmcProgress();
                }
            } else {
                alert('Please provide at least 30 characters for this section.');
            }
            return;
        }
        
        // Regular step navigation
        if (validateCurrentStep()) {
            const businessSize = document.querySelector('select[name="businessSize"]').value;
            
            if (currentStep === 2 && businessSize === 'aspiring-entrepreneur') {
                // Show BMC step for aspiring entrepreneurs
                document.getElementById('bmcStep').style.display = 'flex';
                showStep(3);
                loadBmcSection(currentBmcSection);
                updateBmcProgress();
            } else if (currentStep < totalSteps) {
                // Skip BMC for non-aspiring entrepreneurs
                if (currentStep === 2 && businessSize !== 'aspiring-entrepreneur') {
                    showStep(4); // Skip to Stock Management
                } else {
                    showStep(currentStep + 1);
                }
            }
        }
    });
});

// Previous button handlers
document.querySelectorAll('.btn-previous').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        if (currentStep > 1) {
            showStep(currentStep - 1);
        }
    });
});

// Form validation
function validateCurrentStep() {
    const currentStepEl = document.querySelector(`.form-step[data-step="${currentStep}"]`);
    const requiredFields = currentStepEl.querySelectorAll('[required]');
    let isValid = true;
    let errorMessage = '';
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.style.borderColor = '#ef4444';
            isValid = false;
        } else {
            field.style.borderColor = '';
        }
    });
    
    // Special validation for step 4 textarea
    if (currentStep === 4) {
        const textarea = currentStepEl.querySelector('textarea[name="cycleReason"]');
        if (textarea && textarea.value.trim().length < 20) {
            textarea.style.borderColor = '#ef4444';
            errorMessage = 'Please provide at least 20 characters explaining your stock cycle choice.';
            isValid = false;
        }
    }
    
    if (!isValid) {
        alert(errorMessage || 'Please fill in all required fields.');
    }
    
    return isValid;
}

// Handle conditional fields
document.addEventListener('change', (e) => {
    // Contact form business type dropdown
    if (e.target.id === 'contactBusinessType') {
        const otherField = document.getElementById('contactOtherBusinessType');
        const otherInput = document.getElementById('contactOtherInput');
        if (e.target.value === 'other') {
            otherField.style.display = 'block';
            otherInput.required = true;
        } else {
            otherField.style.display = 'none';
            otherInput.required = false;
        }
    }
    
    // Show/hide other category field
    if (e.target.name === 'businessCategory') {
        const otherField = document.querySelector('.other-category');
        const otherInput = document.querySelector('input[name="otherCategory"]');
        if (e.target.value === 'other') {
            otherField.style.display = 'block';
            otherInput.required = true;
        } else {
            otherField.style.display = 'none';
            otherInput.required = false;
        }
    }
    
    // Show/hide aspiring entrepreneur category and update button text
    if (e.target.id === 'businessSizeSelect') {
        const aspiringField = document.querySelector('.aspiring-category');
        const aspiringSelect = document.querySelector('select[name="aspiringCategory"]');
        const nextBtn = document.getElementById('step2NextBtn');
        
        if (e.target.value === 'aspiring-entrepreneur') {
            aspiringField.style.display = 'block';
            aspiringSelect.required = true;
            if (nextBtn) nextBtn.textContent = 'Start Business Model Canvas';
        } else {
            aspiringField.style.display = 'none';
            aspiringSelect.required = false;
            if (nextBtn) nextBtn.textContent = 'Next Step';
        }
    }
    
    // Show/hide aspiring other category field
    if (e.target.id === 'aspiringCategorySelect') {
        const otherField = document.querySelector('.aspiring-other-category');
        const otherInput = document.querySelector('input[name="aspiringOtherCategory"]');
        if (e.target.value === 'other') {
            otherField.style.display = 'block';
            otherInput.required = true;
        } else {
            otherField.style.display = 'none';
            otherInput.required = false;
        }
    }
});

// Character counter for textarea
const cycleReasonTextarea = document.querySelector('textarea[name="cycleReason"]');
const charCount = document.querySelector('.char-count');

cycleReasonTextarea?.addEventListener('input', () => {
    const count = cycleReasonTextarea.value.length;
    charCount.textContent = count;
    
    if (count >= 20) {
        charCount.style.color = '#10b981';
    } else {
        charCount.style.color = '#ef4444';
    }
});

// Form submission for BMC completion
document.getElementById('bmcComplete')?.addEventListener('click', (e) => {
    e.preventDefault();
    
    // Save current section data
    const currentTextarea = document.querySelector('#bmcContent textarea');
    if (currentTextarea && currentTextarea.value.trim()) {
        bmcData[currentBmcSection] = currentTextarea.value.trim();
        if (currentTextarea.value.trim().length >= 30) {
            completedSections.add(currentBmcSection);
        }
    }
    
    // Check if all sections are completed
    const totalSections = Object.keys(bmcSections).length;
    if (completedSections.size < totalSections) {
        alert(`Please complete all ${totalSections} sections of the Business Model Canvas. You have completed ${completedSections.size} sections.`);
        return;
    }
    
    // Proceed to Stock Management step
    showStep(4);
});

// Regular form submission (for non-BMC users)
vendorRegistrationForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    if (!validateCurrentStep()) {
        return;
    }
    
    submitVendorRegistration();
});

// Business Model Canvas Data
const bmcSections = {
    'value-proposition': {
        title: 'Value Proposition',
        question: 'What unique value do you offer to customers? What problems do you solve?',
        example: 'Fresh vegetables at affordable prices delivered to your doorstep within 2 hours',
        placeholder: 'Describe what makes your business special and valuable to customers...'
    },
    'customer-segments': {
        title: 'Customer Segments',
        question: 'Who are your target customers? What groups of people will buy from you?',
        example: 'Busy working professionals, families with young children, elderly people who cannot travel',
        placeholder: 'Describe your ideal customers and target market...'
    },
    'channels': {
        title: 'Channels',
        question: 'How will you reach and deliver value to your customers?',
        example: 'Mobile app, WhatsApp orders, social media marketing, word-of-mouth referrals',
        placeholder: 'Describe how customers will find and interact with your business...'
    },
    'customer-relationships': {
        title: 'Customer Relationships',
        question: 'How will you build and maintain relationships with customers?',
        example: 'Personal service with regular check-ins, loyalty discounts for repeat customers, WhatsApp customer support group',
        placeholder: 'Describe how you will keep customers happy and coming back...'
    },
    'revenue-streams': {
        title: 'Revenue Streams',
        question: 'How will your business make money? What will customers pay for?',
        example: 'Product sales, delivery fees, subscription for regular deliveries, premium product markup',
        placeholder: 'Describe all the ways your business will generate income...'
    },
    'key-resources': {
        title: 'Key Resources',
        question: 'What key resources does your business need to operate?',
        example: 'Delivery vehicle, storage space, supplier relationships, mobile phone, inventory management system',
        placeholder: 'List the most important assets your business needs...'
    },
    'key-activities': {
        title: 'Key Activities',
        question: 'What are the most important activities your business must do?',
        example: 'Sourcing fresh products, managing inventory, processing orders, making deliveries, customer service',
        placeholder: 'Describe the main activities you must do to run your business...'
    },
    'key-partnerships': {
        title: 'Key Partnerships',
        question: 'Who are your key partners and suppliers that help your business?',
        example: 'Local farmers, wholesale markets, delivery partners, payment processors, stokika for financing',
        placeholder: 'List important partners, suppliers, and collaborators...'
    },
    'cost-structure': {
        title: 'Cost Structure',
        question: 'What are the main costs involved in running your business?',
        example: 'Product purchasing, fuel for delivery, phone credit, storage rent, stokika service fees',
        placeholder: 'List your main business expenses and costs...'
    }
};

let currentBmcSection = 'value-proposition';
let completedSections = new Set();
let bmcData = {};

// BMC Functions
function loadBmcSection(sectionKey) {
    const section = bmcSections[sectionKey];
    const content = document.getElementById('bmcContent');
    const sectionNum = Object.keys(bmcSections).indexOf(sectionKey) + 1;
    
    const sectionElement = document.getElementById('bmcSection');
    sectionElement.textContent = sectionNum;
    sectionElement.style.color = '#eab308';
    
    content.innerHTML = `
        <div class="bmc-section">
            <div class="bmc-icon">📋</div>
            <h4>${section.title}</h4>
            <p class="bmc-question">${section.question}</p>
            <div class="bmc-example">
                <strong>Example:</strong> "${section.example}"
            </div>
            <textarea 
                name="bmc_${sectionKey}" 
                placeholder="${section.placeholder}" 
                minlength="30" 
                required
            >${bmcData[sectionKey] || ''}</textarea>
            <div class="char-counter">
                <span class="char-count">${(bmcData[sectionKey] || '').length}</span>/30 characters minimum
            </div>
        </div>
    `;
    
    // Update grid
    updateBmcGrid(sectionKey);
    
    // Add character counter and auto-resize
    const textarea = content.querySelector('textarea');
    const charCount = content.querySelector('.char-count');
    
    // Auto-resize textarea
    function autoResize() {
        textarea.style.height = 'auto';
        textarea.style.height = Math.max(120, textarea.scrollHeight) + 'px';
    }
    
    textarea.addEventListener('input', () => {
        const count = textarea.value.length;
        charCount.textContent = count;
        charCount.style.color = count >= 30 ? '#10b981' : '#ef4444';
        bmcData[sectionKey] = textarea.value;
        autoResize();
    });
    
    // Initial resize
    setTimeout(autoResize, 100);
}

function updateBmcProgress() {
    const totalSections = Object.keys(bmcSections).length;
    const completedCount = completedSections.size;
    const currentSectionIndex = Object.keys(bmcSections).indexOf(currentBmcSection) + 1;
    
    // Progress includes current section being worked on
    const progress = (currentSectionIndex / totalSections) * 100;
    document.getElementById('bmcProgressBar').style.width = progress + '%';
}

function updateBmcGrid(activeSectionKey) {
    document.querySelectorAll('.bmc-card').forEach(card => {
        card.classList.remove('active');
        if (completedSections.has(card.dataset.section)) {
            card.classList.add('completed');
        } else {
            card.classList.remove('completed');
        }
    });
    
    const activeCard = document.querySelector(`[data-section="${activeSectionKey}"]`);
    if (activeCard) {
        activeCard.classList.add('active');
    }
}

// Add BMC card click navigation
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('bmc-card')) {
        const sectionKey = e.target.dataset.section;
        if (sectionKey && bmcSections[sectionKey]) {
            // Save current section data before switching
            const currentTextarea = document.querySelector('#bmcContent textarea');
            if (currentTextarea && currentTextarea.value.trim()) {
                bmcData[currentBmcSection] = currentTextarea.value.trim();
                if (currentTextarea.value.trim().length >= 30) {
                    completedSections.add(currentBmcSection);
                }
            }
            
            currentBmcSection = sectionKey;
            loadBmcSection(sectionKey);
            updateBmcProgress();
        }
    }
});

// Separate function for vendor registration submission
async function submitVendorRegistration() {
    // Rate limiting check
    if (!SecurityConfig.rateLimiter.canAttempt('vendorReg', 3, 300000)) {
        alert('Too many attempts. Please try again in 5 minutes.');
        return;
    }
    
    const formData = new FormData(vendorRegistrationForm);
    const rawData = Object.fromEntries(formData);
    
    // Sanitize all inputs
    const sanitizedData = {};
    Object.keys(rawData).forEach(key => {
        sanitizedData[key] = SecurityConfig.sanitizeInput(rawData[key]);
    });
    
    // Validate required fields
    const requiredFields = ['businessName', 'email', 'phone'];
    const missingFields = requiredFields.filter(field => !sanitizedData[field] || sanitizedData[field].trim() === '');
    if (missingFields.length > 0) {
        alert(`Please fill in all required fields: ${missingFields.join(', ')}`);
        return;
    }
    
    // Validate email and phone
    if (!SecurityConfig.validateEmail(sanitizedData.email)) {
        alert('Please enter a valid email address.');
        return;
    }
    if (!SecurityConfig.validatePhone(sanitizedData.phone)) {
        alert('Please enter a valid phone number.');
        return;
    }
    
    // Prepare data including BMC if aspiring entrepreneur
    const data = {
        business_name: sanitizedData.businessName,
        business_category: sanitizedData.businessCategory === 'other' ? sanitizedData.otherCategory : sanitizedData.businessCategory,
        county: sanitizedData.county,
        town: sanitizedData.town,
        center: sanitizedData.center,
        phone: sanitizedData.phone,
        email: sanitizedData.email,
        business_size: sanitizedData.businessSize,
        stock_cycle: sanitizedData.stockCycle,
        stock_limit: parseInt(sanitizedData.stockLimit) || 0,
        cycle_reason: sanitizedData.cycleReason
    };
    
    // Add BMC data if aspiring entrepreneur
    if (sanitizedData.businessSize === 'aspiring-entrepreneur') {
        data.business_model_canvas = bmcData;
        data.aspiring_category = sanitizedData.aspiringCategory === 'other' ? sanitizedData.aspiringOtherCategory : sanitizedData.aspiringCategory;
    }
    
    // Show loading state
    const submitBtn = document.querySelector('#bmcComplete, .btn-next[id="stockToCanvas"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Submitting...';
    submitBtn.disabled = true;
    
    try {
        const { data: result, error } = await supabase
            .from('vendors')
            .insert([data]);
        
        if (error) throw error;
        
        alert('Registration submitted successfully! We will contact you within 24 hours.');
        vendorRegistrationModal.classList.remove('active');
        resetVendorForm();
    } catch (error) {
        console.error('Error submitting vendor registration:', error);
        alert('There was an error submitting your registration. Please try again.');
    } finally {
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }
}

// Reset form function
function resetVendorForm() {
    vendorRegistrationForm?.reset();
    currentStep = 1;
    currentBmcSection = 'value-proposition';
    completedSections.clear();
    bmcData = {};
    showStep(1);
    
    // Hide BMC step
    document.getElementById('bmcStep').style.display = 'none';
    
    // Reset BMC buttons
    const bmcNext = document.getElementById('bmcNext');
    const bmcComplete = document.getElementById('bmcComplete');
    if (bmcNext) bmcNext.style.display = 'block';
    if (bmcComplete) bmcComplete.style.display = 'none';
    
    // Reset character counter
    const charCount = document.querySelector('.char-count');
    if (charCount) {
        charCount.textContent = '0';
        charCount.style.color = '#ef4444';
    }
    
    // Reset field borders
    document.querySelectorAll('.vendor-form input, .vendor-form select, .vendor-form textarea').forEach(field => {
        field.style.borderColor = '';
    });
    
    // Reset conditional fields
    document.querySelectorAll('.other-category, .aspiring-category, .aspiring-other-category').forEach(field => {
        field.style.display = 'none';
        const input = field.querySelector('input, select');
        if (input) input.required = false;
    });
}

// Remove conflicting event listeners
vendorRegistrationModal?.addEventListener('transitionend', (e) => {
    if (e.target === vendorRegistrationModal && vendorRegistrationModal.classList.contains('active')) {
        if (currentStep === 1) {
            showStep(1);
        }
    }
});

// Auto-advance hero slides (optional)
let autoAdvanceInterval;

function startAutoAdvance() {
    autoAdvanceInterval = setInterval(() => {
        if (currentSlide < slides.length - 1) {
            scrollToSlide(currentSlide + 1);
        } else {
            scrollToSlide(0);
        }
    }, 5000);
}

function stopAutoAdvance() {
    clearInterval(autoAdvanceInterval);
}

// Uncomment to enable auto-advance
// startAutoAdvance();

// Stop auto-advance when user interacts
heroSection?.addEventListener('scroll', stopAutoAdvance);
heroSection?.addEventListener('touchstart', stopAutoAdvance);
