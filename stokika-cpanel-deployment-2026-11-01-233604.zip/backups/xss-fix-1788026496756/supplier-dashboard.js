// Supplier Dashboard JavaScript

let currentSupplierId = null;

document.addEventListener('DOMContentLoaded', async () => {
    // Auth protection is handled in HTML inline script
    
    currentSupplierId = authMiddleware.getUserId();
    const supplierName = authMiddleware.getUserName();
    
    document.getElementById('supplierName').textContent = supplierName;
    
    // Get actual supplier ID from suppliers table
    const supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
    const { data: supplier } = await supabase
        .from('suppliers')
        .select('id')
        .eq('user_id', currentSupplierId)
        .single();
    
    if (supplier) {
        currentSupplierId = supplier.id;
    }
    
    // Page navigation
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page-content');
    
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const pageName = item.dataset.page;
            
            navItems.forEach(nav => nav.classList.remove('active'));
            pages.forEach(page => page.classList.remove('active'));
            
            item.classList.add('active');
            document.getElementById(`${pageName}-page`).classList.add('active');
            document.getElementById('pageTitle').textContent = item.querySelector('span').textContent;
            
            loadPageData(pageName, supplierId);
        });
    });
    
    // Load initial data
    loadOverviewData(currentSupplierId);
});

async function loadPageData(pageName, supplierId) {
    switch(pageName) {
        case 'overview':
            loadOverviewData(supplierId);
            break;
        case 'orders':
            loadAllOrders(supplierId);
            break;
        case 'products':
            loadProducts(supplierId);
            break;
        case 'payments':
            loadPayments(supplierId);
            break;
        case 'profile':
            loadProfile(supplierId);
            break;
    }
}

async function loadOverviewData(supplierId) {
    try {
        const supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
        const { data: orders } = await supabase
            .from('orders')
            .select('*, vendors(name)')
            .eq('supplier_id', supplierId)
            .order('created_at', { ascending: false });
        const ordersArray = orders || [];
        
        document.getElementById('totalOrders').textContent = ordersArray.length;
        document.getElementById('pendingOrders').textContent = ordersArray.filter(o => o.status === 'pending').length;
        
        const revenue = ordersArray.reduce((sum, o) => sum + (o.total_amount || 0), 0);
        document.getElementById('totalRevenue').textContent = `KES ${revenue.toLocaleString()}`;
        
        // Load recent orders
        const recentList = document.getElementById('recentOrdersList');
        if (ordersArray.length > 0) {
            recentList.innerHTML = ordersArray.slice(0, 5).map(order => `
                <div class="order-item">
                    <div>
                        <strong>${order.order_number}</strong>
                        <div style="font-size: 0.875rem; color: #64748b;">
                            ${order.vendors?.name || 'Vendor'} - KES ${order.total_amount?.toLocaleString()}
                        </div>
                    </div>
                    <span class="status-badge ${order.status}">${order.status}</span>
                </div>
            `).join('');
        } else {
            recentList.innerHTML = '<div class="empty-state">No orders yet</div>';
        }
    } catch (error) {
        console.error('Error loading overview:', error);
    }
}

async function loadAllOrders(supplierId) {
    const list = document.getElementById('allOrdersList');
    list.innerHTML = '<div class="loading">Loading orders...</div>';
    
    try {
        const supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
        const { data: orders } = await supabase
            .from('orders')
            .select('*, vendors(name)')
            .eq('supplier_id', supplierId)
            .order('created_at', { ascending: false });
        
        if (orders && orders.length > 0) {
            list.innerHTML = orders.map(order => `
                <div class="order-item">
                    <div>
                        <strong>${order.order_number}</strong>
                        <div style="font-size: 0.875rem; color: #64748b;">
                            ${order.vendors?.name || 'Vendor'} - ${new Date(order.created_at).toLocaleDateString()}
                        </div>
                        <div style="margin-top: 0.5rem;">KES ${order.total_amount?.toLocaleString()}</div>
                    </div>
                    <span class="status-badge ${order.status}">${order.status}</span>
                </div>
            `).join('');
        } else {
            list.innerHTML = '<div class="empty-state">No orders found</div>';
        }
    } catch (error) {
        console.error('Error loading orders:', error);
        list.innerHTML = '<div class="empty-state">Error loading orders</div>';
    }
}

async function loadProducts(supplierId) {
    const list = document.getElementById('productsList');
    list.innerHTML = '<div class="loading">Loading products...</div>';
    
    try {
        const supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
        const { data: products } = await supabase
            .from('products')
            .select('*')
            .eq('supplier_id', supplierId);
        
        document.getElementById('totalProducts').textContent = products?.length || 0;
        
        if (products && products.length > 0) {
            list.innerHTML = products.map(product => `
                <div class="product-item">
                    <div>
                        <strong>${product.name}</strong>
                        <div style="font-size: 0.875rem; color: #64748b;">
                            ${product.category || 'Uncategorized'} - Stock: ${product.stock_quantity || 0}
                        </div>
                    </div>
                    <div style="font-weight: 600;">KES ${product.unit_price?.toLocaleString()}</div>
                </div>
            `).join('');
        } else {
            list.innerHTML = '<div class="empty-state">No products listed yet</div>';
        }
    } catch (error) {
        console.error('Error loading products:', error);
        list.innerHTML = '<div class="empty-state">Error loading products</div>';
    }
}

async function loadPayments(supplierId) {
    const list = document.getElementById('paymentsList');
    list.innerHTML = '<div class="loading">Loading payments...</div>';
    
    try {
        const supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
        const { data: payments } = await supabase
            .from('payments')
            .select('*, orders(order_number)')
            .eq('orders.supplier_id', supplierId);
        
        if (payments && payments.length > 0) {
            list.innerHTML = payments.map(payment => `
                <div class="payment-item">
                    <div>
                        <strong>${payment.orders?.order_number || 'N/A'}</strong>
                        <div style="font-size: 0.875rem; color: #64748b;">
                            ${new Date(payment.created_at).toLocaleDateString()}
                        </div>
                    </div>
                    <div>
                        <div style="font-weight: 600;">KES ${payment.amount?.toLocaleString()}</div>
                        <span class="status-badge ${payment.status}">${payment.status}</span>
                    </div>
                </div>
            `).join('');
        } else {
            list.innerHTML = '<div class="empty-state">No payment history</div>';
        }
    } catch (error) {
        console.error('Error loading payments:', error);
        list.innerHTML = '<div class="empty-state">Error loading payments</div>';
    }
}

async function loadProfile(supplierId) {
    const content = document.getElementById('profileContent');
    content.innerHTML = '<div class="loading">Loading profile...</div>';
    
    try {
        const supabase = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
        const { data: supplier } = await supabase
            .from('suppliers')
            .select('*')
            .eq('id', supplierId)
            .single();
        
        if (supplier) {
            content.innerHTML = `
                <div style="max-width: 600px;">
                    <div style="margin-bottom: 1.5rem;">
                        <label style="display: block; font-weight: 600; margin-bottom: 0.5rem;">Company Name</label>
                        <div style="padding: 0.75rem; background: #f8fafc; border-radius: 8px;">${sanitize(supplier.name)}</div>
                    </div>
                    <div style="margin-bottom: 1.5rem;">
                        <label style="display: block; font-weight: 600; margin-bottom: 0.5rem;">Email</label>
                        <div style="padding: 0.75rem; background: #f8fafc; border-radius: 8px;">${sanitize(supplier.email || 'N/A')}</div>
                    </div>
                    <div style="margin-bottom: 1.5rem;">
                        <label style="display: block; font-weight: 600; margin-bottom: 0.5rem;">Phone</label>
                        <div style="padding: 0.75rem; background: #f8fafc; border-radius: 8px;">${sanitize(supplier.phone)}</div>
                    </div>
                    <div style="margin-bottom: 1.5rem;">
                        <label style="display: block; font-weight: 600; margin-bottom: 0.5rem;">Location</label>
                        <div style="padding: 0.75rem; background: #f8fafc; border-radius: 8px;">${sanitize(supplier.location || 'N/A')}</div>
                    </div>
                    <div style="margin-bottom: 1.5rem;">
                        <label style="display: block; font-weight: 600; margin-bottom: 0.5rem;">Verification Status</label>
                        <div style="padding: 0.75rem; background: #f8fafc; border-radius: 8px;">
                            <span class="status-badge ${sanitize(supplier.verified ? 'delivered' : 'pending')}">
                                ${sanitize(supplier.verified ? 'Verified' : 'Pending Verification')}
                            </span>
                        </div>
                    </div>
                </div>
            `;
        } else {
            content.innerHTML = '<div class="empty-state">Profile not found</div>';
        }
    } catch (error) {
        console.error('Error loading profile:', error);
        content.innerHTML = '<div class="empty-state">Error loading profile</div>';
    }
}

// Add product button handler
document.getElementById('addProductBtn')?.addEventListener('click', () => {
    alert('Add product functionality coming soon!');
});
